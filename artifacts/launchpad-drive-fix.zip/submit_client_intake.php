<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ob_start();

require_once __DIR__ . '/cors_helpers.php';

function setCorsHeadersForClientIntake() {
    launchpad_apply_cors_headers('POST, OPTIONS');
}

register_shutdown_function(function () {
    $err = error_get_last();
    if (!$err) return;

    $fatalTypes = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR];
    if (!in_array($err['type'], $fatalTypes, true)) return;

    while (ob_get_level() > 0) {
        @ob_end_clean();
    }

    setCorsHeadersForClientIntake();
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8', true);
        echo json_encode([
            'success' => false,
            'title' => 'Submission Failed',
            'message' => 'Internal server error while submitting the client intake form.',
        ]);
    }
});

$autoload = __DIR__ . '/../vendor/autoload.php';
if (file_exists($autoload)) {
    require_once $autoload;
}

require_once 'config.php';

if (file_exists(__DIR__ . '/drive_helper.php')) {
    require_once __DIR__ . '/drive_helper.php';
}

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    setCorsHeadersForClientIntake();
    http_response_code(200);
    exit;
}

setCorsHeadersForClientIntake();
header('Content-Type: application/json; charset=utf-8', true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'title' => 'Submission Failed',
        'message' => 'Invalid request method.',
    ]);
    exit;
}

function intake_string($payload, $key) {
    if (!is_array($payload) || !array_key_exists($key, $payload)) return '';
    $value = $payload[$key];
    if (is_array($value) || is_object($value)) return '';
    return trim((string)$value);
}

function intake_bool($payload, $key) {
    return is_array($payload) && !empty($payload[$key]);
}

function intake_valid_signature($value) {
    return is_string($value) && preg_match('/^data:image\/(png|jpeg|jpg);base64,[A-Za-z0-9+\/=]+$/', $value) === 1;
}

function intake_sanitize_drive_folder_id($raw): ?string {
    $raw = trim((string)$raw);
    if ($raw === '' || preg_match('#^https?://#i', $raw)) {
        return null;
    }
    if (!preg_match('/^[A-Za-z0-9_-]{10,}$/', $raw)) {
        return null;
    }
    return $raw;
}

/**
 * Resolve Drive folder + filename for a client intake signature upload.
 *
 * Prefer uploading directly into a configured parent folder (no subfolder create).
 * Subfolder creation is optional and only attempted when no direct parent is configured.
 *
 * @return array{folderId:string,uploadFilename:string,drivePathFolderId:string}
 */
function intake_resolve_drive_upload_target(int $intakeId, string $storedFilename, bool $useSharedDrive): array {
    $folderName = 'client_intake_' . $intakeId;
    $intakeParentEnv = intake_sanitize_drive_folder_id(getenv('GOOGLE_DRIVE_CLIENT_INTAKE_FOLDER_ID'));
    $signedOffersFolderId = intake_sanitize_drive_folder_id(getenv('GOOGLE_DRIVE_SIGNED_OFFERS_FOLDER_ID'));
    $rootFolderId = function_exists('getDriveRootFolderId') ? intake_sanitize_drive_folder_id(getDriveRootFolderId()) : null;

    // Direct upload avoids getOrCreateDriveFolder failures on Shared Drive roots.
    $directParents = array_values(array_filter(array_unique([
        $intakeParentEnv,
        $signedOffersFolderId,
    ])));
    if (!empty($directParents)) {
        return [
            'folderId' => $directParents[0],
            'uploadFilename' => $folderName . '_' . $storedFilename,
            'drivePathFolderId' => $directParents[0],
        ];
    }

    $candidates = array_values(array_filter([$rootFolderId]));
    $lastError = 'No Drive parent folder configured';
    foreach ($candidates as $parentId) {
        try {
            $folderId = getOrCreateDriveFolder($folderName, $parentId, $useSharedDrive);
            if ($folderId) {
                return [
                    'folderId' => $folderId,
                    'uploadFilename' => $storedFilename,
                    'drivePathFolderId' => $folderId,
                ];
            }
            $lastError = 'getOrCreateDriveFolder returned null';
        } catch (Throwable $e) {
            $lastError = $e->getMessage();
        }
    }

    throw new Exception($lastError);
}

function intake_decode_signature_data_url(string $dataUrl): array {
    if (!preg_match('/^data:image\/(png|jpeg|jpg);base64,(.+)$/', $dataUrl, $matches)) {
        throw new Exception('Invalid signature format.');
    }

    $imageData = base64_decode($matches[2], true);
    if ($imageData === false) {
        throw new Exception('Failed to decode signature image.');
    }

    $maxBytes = 2 * 1024 * 1024;
    if (strlen($imageData) > $maxBytes) {
        throw new Exception('Signature image is too large (max 2MB).');
    }

    $sha256 = hash('sha256', $imageData);
    if ($sha256 === false) {
        throw new Exception('Failed to hash signature image.');
    }

    return [
        'imageData' => $imageData,
        'sha256' => $sha256,
        'sizeBytes' => strlen($imageData),
        'mime_type' => 'image/png',
        'storedFilename' => bin2hex(random_bytes(16)) . '.png',
        'original_filename' => 'signature.png',
    ];
}

function intake_save_signature_attachment(
    mysqli $conn,
    int $intakeId,
    int $uploadedByUserId,
    string $attachmentType,
    string $dataUrl,
    bool $driveEnabled,
    array &$savedLocalFiles,
    array &$driveFallbacks,
    array &$driveErrors
): void {
    $decoded = intake_decode_signature_data_url($dataUrl);
    $folderName = 'client_intake_' . $intakeId;
    $storedFilename = $decoded['storedFilename'];
    $storedPath = '';
    $storedFileRef = $storedFilename;
    $savedToDrive = false;

    if (
        $driveEnabled &&
        function_exists('uploadFileContentToDrive') &&
        function_exists('getOrCreateDriveFolder')
    ) {
        try {
            if (!function_exists('getGoogleDriveClient') || !getGoogleDriveClient()) {
                throw new Exception(
                    'Drive OAuth client unavailable. Re-link Drive in Launchpad (required after changing GOOGLE_DRIVE_SCOPES).'
                );
            }

            $useSharedDrive = isSharedDriveEnabled();
            $driveTarget = intake_resolve_drive_upload_target($intakeId, $storedFilename, $useSharedDrive);
            $folderId = $driveTarget['folderId'];
            $uploadFilename = $driveTarget['uploadFilename'];

            $driveResult = uploadFileContentToDrive(
                $decoded['imageData'],
                $uploadFilename,
                $decoded['mime_type'],
                $folderId,
                $useSharedDrive
            );
            if (!$driveResult || !isset($driveResult['fileId'])) {
                throw new Exception('uploadFileContentToDrive failed');
            }

            $storedPath = 'drive://' . $driveTarget['drivePathFolderId'];
            $storedFileRef = $driveResult['fileId'];
            $savedToDrive = true;
        } catch (Throwable $e) {
            $driveFallbacks[] = $attachmentType;
            $driveErrors[] = [
                'type' => $attachmentType,
                'error' => $e->getMessage(),
            ];
            error_log(
                "Drive client intake signature upload failed; falling back to local. intake_id={$intakeId} type={$attachmentType} err="
                . $e->getMessage()
            );
        }
    }

    if (!$savedToDrive) {
        $dirAbs = __DIR__ . '/uploads/' . $folderName;
        if (!is_dir($dirAbs) && !mkdir($dirAbs, 0755, true)) {
            throw new Exception('Failed to create upload directory for client intake signature.');
        }

        $destAbs = rtrim($dirAbs, '/\\') . DIRECTORY_SEPARATOR . $storedFilename;
        if (file_put_contents($destAbs, $decoded['imageData']) === false) {
            throw new Exception('Failed to save client intake signature locally.');
        }

        $savedLocalFiles[] = $destAbs;
        $storedPath = 'uploads/' . $folderName;
        $storedFileRef = $storedFilename;
    }

    $sql = "
        INSERT INTO ClientIntakeAttachments
            (intake_id, uploaded_by_user_id, attachment_type,
             original_filename, stored_path, stored_filename,
             mime_type, size_bytes, sha256, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception('Client intake attachment SQL prepare failed: ' . $conn->error);
    }

    $stmt->bind_param(
        'iisssssis',
        $intakeId,
        $uploadedByUserId,
        $attachmentType,
        $decoded['original_filename'],
        $storedPath,
        $storedFileRef,
        $decoded['mime_type'],
        $decoded['sizeBytes'],
        $decoded['sha256']
    );

    if (!$stmt->execute()) {
        throw new Exception('Client intake attachment insert failed: ' . $stmt->error);
    }
    $stmt->close();
}

$response = [
    'success' => false,
    'title' => 'Submission Failed',
    'message' => 'An unexpected error occurred.',
];

$conn = null;
$savedLocalFiles = [];
$driveFallbacks = [];
$driveErrors = [];

try {
    $authUser = requireUser();
    $role = isset($authUser['role']) ? strtolower((string)$authUser['role']) : 'staff';
    $canSubmit = in_array($role, ['admin', 'hr', 'staff', 'employee'], true);
    if (!$canSubmit) {
        http_response_code(403);
        throw new Exception('Only Admin, HR, and Staff can submit client intake packets.');
    }

    $raw = file_get_contents('php://input');
    $payload = json_decode($raw, true);
    if (!is_array($payload)) {
        throw new Exception('Invalid JSON payload.');
    }

    $childLegalName = intake_string($payload, 'childLegalName');
    $childDob = intake_string($payload, 'childDob');
    $completedBy = intake_string($payload, 'completedBy');
    $childHomeAddress = intake_string($payload, 'childHomeAddress');
    $homePhone = intake_string($payload, 'homePhone');
    $cellPhone = intake_string($payload, 'cellPhone');
    $therapyGoals = intake_string($payload, 'therapyGoals');
    $diagnosis = intake_string($payload, 'diagnosis');
    $parentSignature = intake_string($payload, 'parentGuardianSignature');
    $parentSignatureDate = intake_string($payload, 'parentGuardianSignatureDate');
    $providerSignature = intake_string($payload, 'providerSignature');
    $providerSignatureDate = intake_string($payload, 'providerSignatureDate');

    if ($childLegalName === '') throw new Exception('Legal name of child is required.');
    if ($childDob === '') throw new Exception("Child's date of birth is required.");
    if ($completedBy === '') throw new Exception('Name of person completing this form is required.');
    if ($childHomeAddress === '') throw new Exception("Child's home address is required.");
    if ($homePhone === '' && $cellPhone === '') throw new Exception('At least one telephone number is required.');
    if ($therapyGoals === '') throw new Exception('Therapy goals are required.');
    if ($diagnosis === '') throw new Exception("Child's diagnosis is required.");
    if (!intake_bool($payload, 'caregiverGuidelinesAccepted')) {
        throw new Exception('Caregiver guidelines must be accepted.');
    }
    if (!intake_valid_signature($parentSignature)) {
        throw new Exception('Parent/guardian signature is required.');
    }
    if ($parentSignatureDate === '') {
        throw new Exception('Parent/guardian signature date is required.');
    }
    if ($providerSignature !== '' && !intake_valid_signature($providerSignature)) {
        throw new Exception('Invalid provider signature format.');
    }
    if ($providerSignature !== '' && $providerSignatureDate === '') {
        throw new Exception('Provider signature date is required when provider signature is captured.');
    }

    $createdByUserId = isset($authUser['id']) ? (int)$authUser['id'] : null;
    if (!$createdByUserId) {
        throw new Exception('Authentication required. Please log in again.');
    }

    $payloadJson = json_encode($payload, JSON_UNESCAPED_SLASHES);
    if ($payloadJson === false) {
        throw new Exception('Failed to encode intake payload.');
    }

    $contactPhone = $cellPhone !== '' ? $cellPhone : $homePhone;
    $providerSignatureNullable = $providerSignature !== '' ? $providerSignature : null;
    $providerSignatureDateNullable = $providerSignatureDate !== '' ? $providerSignatureDate : null;
    $driveEnabled = function_exists('isGoogleDriveEnabled') && isGoogleDriveEnabled();

    $conn = getDBConnection();
    $conn->begin_transaction();

    $stmt = $conn->prepare("
        INSERT INTO ClientIntakePackets
            (created_by_user_id, child_legal_name, child_dob, completed_by,
             contact_phone, payload_json, parent_guardian_signature_data_url,
             parent_guardian_signature_date, provider_signature_data_url,
             provider_signature_date, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ");
    if (!$stmt) {
        throw new Exception('Client intake SQL prepare failed: ' . $conn->error);
    }

    $stmt->bind_param(
        'isssssssss',
        $createdByUserId,
        $childLegalName,
        $childDob,
        $completedBy,
        $contactPhone,
        $payloadJson,
        $parentSignature,
        $parentSignatureDate,
        $providerSignatureNullable,
        $providerSignatureDateNullable
    );

    if (!$stmt->execute()) {
        throw new Exception('Client intake insert failed: ' . $stmt->error);
    }

    $intakeId = (int)$conn->insert_id;
    $stmt->close();

    intake_save_signature_attachment(
        $conn,
        $intakeId,
        $createdByUserId,
        'PARENT_GUARDIAN_SIGNATURE',
        $parentSignature,
        $driveEnabled,
        $savedLocalFiles,
        $driveFallbacks,
        $driveErrors
    );

    if ($providerSignature !== '') {
        intake_save_signature_attachment(
            $conn,
            $intakeId,
            $createdByUserId,
            'PROVIDER_SIGNATURE',
            $providerSignature,
            $driveEnabled,
            $savedLocalFiles,
            $driveFallbacks,
            $driveErrors
        );
    }

    $conn->commit();

    $response = [
        'success' => true,
        'title' => 'Client Intake Submitted',
        'message' => "Client intake packet for {$childLegalName} submitted successfully.",
        'intake_id' => $intakeId,
        'drive' => [
            'enabled' => (bool)$driveEnabled,
            'connected' => function_exists('isDriveOAuthConnected') ? isDriveOAuthConnected() : null,
            'fallbacks' => array_values(array_unique($driveFallbacks)),
            'errors' => $driveErrors,
            'hint' => empty($driveFallbacks)
                ? null
                : (function_exists('isDriveOAuthConnected') && !isDriveOAuthConnected()
                    ? 'Drive OAuth is not connected. Re-link Drive in Launchpad after updating GOOGLE_DRIVE_SCOPES.'
                    : 'Drive upload failed and signatures were saved locally. See drive.errors for details.'),
        ],
    ];
} catch (Throwable $e) {
    if ($conn instanceof mysqli) {
        $conn->rollback();
    }
    foreach ($savedLocalFiles as $path) {
        if (is_string($path) && file_exists($path)) {
            @unlink($path);
        }
    }
    $response['message'] = $e->getMessage();
    error_log('Client intake submission error: ' . $e->getMessage());
} finally {
    if ($conn instanceof mysqli) {
        $conn->close();
    }
}

while (ob_get_level() > 0) {
    @ob_end_clean();
}

setCorsHeadersForClientIntake();
header('Content-Type: application/json; charset=utf-8', true);
echo json_encode($response);
?>
